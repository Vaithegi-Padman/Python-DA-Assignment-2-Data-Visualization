import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# Load the taxis dataset
df = sns.load_dataset("taxis")
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
# Load the taxis dataset
df = sns.load_dataset("taxis")
# Display the first 5 rows
print(df.head())
# Display dataset information
print(df.info())
# Display number of rows and columns
print("Shape of the dataset:", df.shape)
# Display column names
print("Column names:")
print(df.columns)
# Check missing values in each column
print("Missing values in each column:")
print(df.isnull().sum())
# Identify columns that contain missing values
missing_columns = df.columns[df.isnull().any()]

print("\nColumns with missing values:")
print(missing_columns)
# Calculate missing value percentage
missing_percentage = (df.isnull().sum() / len(df)) * 100

print("\nMissing value percentage:")
print(missing_percentage[missing_percentage > 0])
# Identify numerical columns
numerical_columns = df.select_dtypes(include=['number']).columns

# Fill missing numerical values using median
for col in numerical_columns:
    df[col] = df[col].fillna(df[col].median())
    # Identify categorical columns
categorical_columns = df.select_dtypes(include=['object', 'category']).columns

# Fill missing categorical values using mode
for col in categorical_columns:
    if df[col].isnull().any() and not df[col].mode().empty:
        df[col] = df[col].fillna(df[col].mode()[0])
        # Define critical columns
critical_columns = ['pickup', 'dropoff', 'distance', 'fare', 'total']

# Remove rows with missing values in critical columns
df.dropna(subset=critical_columns, inplace=True)
# Check missing values after cleaning
print("\nMissing values after cleaning:")
print(df.isnull().sum())

# Display final dataset shape
print("\nShape of the cleaned dataset:")
print(df.shape)
# Convert pickup column to datetime
df['pickup'] = pd.to_datetime(df['pickup'])

print(df['pickup'].dtype)
# Sort dataset by pickup timestamp
df = df.sort_values(by='pickup')
# Plot fare over time
plt.figure(figsize=(12, 6))

plt.plot(df['pickup'], df['fare'])

# Add chart title and labels
plt.title('Taxi Fare Over Time')
plt.xlabel('Pickup Timestamp')
plt.ylabel('Fare Amount')

# Display grid
plt.grid(True)

# Display the chart
plt.show()
# Group data by pickup borough and calculate total fare
borough_fare = df.groupby('pickup_borough')['fare'].sum()

print("Total Fare by Pickup Borough:")
print(borough_fare)
# Create bar chart
borough_fare.plot(kind='bar', figsize=(10, 6))

# Add title and labels
plt.title('Total Taxi Fare by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Total Fare Amount')

# Rotate x-axis labels
plt.xticks(rotation=45)

# Display grid
plt.grid(axis='y')

# Display chart
plt.tight_layout()
plt.show()
# BAR CHART: TOTAL FARE BY PICKUP BOROUGH
# Group data by pickup borough
borough_fare = df.groupby('pickup_borough')['fare'].sum()

print("Total Fare by Pickup Borough:")
print(borough_fare)
# Create bar chart
plt.figure(figsize=(10, 6))

borough_fare.plot(kind='bar')

plt.title('Total Taxi Fare by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Total Fare Amount')

plt.xticks(rotation=45)
plt.grid(axis='y')

plt.tight_layout()
# Save chart as an image
plt.savefig('borough_fare_chart.png')

# Display chart
plt.show()
# Count trips by payment method
payment_counts = df['payment'].value_counts()

print("Number of Trips by Payment Method:")
print(payment_counts)
# PIE CHART: TRIP DISTRIBUTION BY PAYMENT METHOD

# Step 1: Count trips by payment method
payment_counts = df['payment'].value_counts()

print("Number of Trips by Payment Method:")
print(payment_counts)

# Step 2: Create pie chart
plt.figure(figsize=(8, 8))

plt.pie(
    payment_counts,
    labels=payment_counts.index,
    autopct='%1.1f%%',
    startangle=90
)

# Step 3: Add title
plt.title('Trip Distribution by Payment Method')

# Step 4: Display chart
plt.tight_layout()
plt.show()
# HISTOGRAM: DISTRIBUTION OF TAXI TRIP DISTANCE

# Step 1: Check distance statistics
print("Distance Statistics:")
print(df['distance'].describe())

# Step 2: Create histogram
plt.figure(figsize=(10, 6))

plt.hist(
    df['distance'],
    bins=20,
    edgecolor='black'
)

# Step 3: Add title and labels
plt.title('Distribution of Taxi Trip Distance')
plt.xlabel('Trip Distance')
plt.ylabel('Frequency')

# Step 4: Add grid
plt.grid(axis='y', alpha=0.5)

# Step 5: Display chart
plt.tight_layout()
plt.show()
# BOX PLOT: TIP DISTRIBUTION BY PICKUP BOROUGH

# Step 1: Check tip statistics
print("Tip Amount Statistics:")
print(df['tip'].describe())

# Step 2: Create box plot
plt.figure(figsize=(10, 6))

sns.boxplot(
    x='pickup_borough',
    y='tip',
    data=df
)

# Step 3: Add title and labels
plt.title('Distribution of Tip Amounts by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Tip Amount')

plt.xticks(rotation=45)

plt.tight_layout()
plt.show()
# VISUALIZATIONS USING SEABORN

# COUNT PLOT: NUMBER OF TRIPS BY PICKUP BOROUGH

# Step 1: Count trips by borough
print("Number of Trips by Pickup Borough:")
print(df['pickup_borough'].value_counts())

# Step 2: Create count plot
plt.figure(figsize=(10, 6))

sns.countplot(x='pickup_borough', data=df)

# Step 3: Add title and labels
plt.title('Number of Taxi Trips by Pickup Borough')
plt.xlabel('Pickup Borough')
plt.ylabel('Number of Trips')

plt.xticks(rotation=45)

plt.tight_layout()
plt.show()
# SEABORN VISUALIZATIONS

# SCATTER PLOT: DISTANCE VS FARE

# Create scatter plot
plt.figure(figsize=(10, 6))

sns.scatterplot(
    x='distance',
    y='fare',
    hue='pickup_borough',
    data=df
)

# Add chart title and labels
plt.title('Relationship Between Taxi Distance and Fare')
plt.xlabel('Trip Distance')
plt.ylabel('Fare Amount')

# Display legend
plt.legend(title='Pickup Borough')

plt.tight_layout()
plt.show()
# HEATMAP: CORRELATION BETWEEN NUMERICAL VARIABLES

# Step 1: Select numerical columns
numeric_data = df[['distance', 'fare', 'tip', 'tolls', 'total']]

# Step 2: Calculate correlation matrix
correlation_matrix = numeric_data.corr()

print("Correlation Matrix:")
print(correlation_matrix)
# Step 3: Create heatmap
plt.figure(figsize=(10, 6))

sns.heatmap(
    correlation_matrix,
    annot=True,
    cmap='coolwarm',
    fmt='.2f',
    linewidths=0.5
)
# Step 4: Add chart title
plt.title('Correlation Heatmap of Taxi Data')

plt.tight_layout()
plt.show()
# PAIR PLOT: PAIRWISE RELATIONSHIPS

# Select required columns
pairplot_data = df[['distance', 'fare', 'tip', 'total', 'pickup_zone']]

# Remove missing values
pairplot_data = pairplot_data.dropna().copy()

# Create pair plot
g = sns.pairplot(
    data=pairplot_data,
    vars=['distance', 'fare', 'tip', 'total'],
    hue='pickup_zone',
    corner=True,
    diag_kind='kde',
    plot_kws={'alpha': 0.5, 's': 15}
)
# Add title
g.figure.suptitle(
    'Pair Plot of Taxi Variables by Pickup Zone',
    y=1.02
)
# Save chart
g.figure.savefig('taxi_pairplot.png', bbox_inches='tight')
print("Pair plot created successfully!")
plt.show()
# Violin Plot - Distribution of Fare by Payment Method
plt.figure(figsize=(10, 6))

sns.violinplot(
    x='payment',
    y='fare',
    data=df,
    inner='quartile'
)

plt.title('Distribution of Fare by Payment Method')
plt.xlabel('Payment Method')
plt.ylabel('Fare Amount')
plt.grid(axis='y', linestyle='--', alpha=0.5)

plt.savefig('taxi_violinplot.png', bbox_inches='tight')

print("Violin plot created successfully!")
plt.show()